# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent
from pacman import GameState
from multiAgents import MultiAgentSearchAgent


class MinimaxAgent(MultiAgentSearchAgent):
    def getAction(self, gameState: GameState):
        """
        Sua lógica principal do Minimax que retorna a melhor ação.
        """

        def minimax(agentIndex=0, depth=0, state=gameState):
            # 5.2. Condição de Parada (Base Case) [cite: 44, 45, 46]
            if state.isWin() or state.isLose() or depth == self.depth:
                return self.evaluationFunction(state)

            # 5.3. Gerenciamento de Agentes e Profundidade [cite: 48, 50, 55]
            # Calcula o próximo agente e se a profundidade deve aumentar
            numAgents = state.getNumAgents()
            nextAgent = (agentIndex + 1) % numAgents
            nextDepth = depth + 1 if nextAgent == 0 else depth

            # Obter ações legais para o agente atual [cite: 62, 73]
            actions = state.getLegalActions(agentIndex)
            
            # Caso não haja ações legais (ex: encurralado), retorna a avaliação [cite: 99, 100]
            if not actions:
                return self.evaluationFunction(state)

            # 5.4. Lógica de Maximização (Turno do Pac-Man: agentIndex 0) [cite: 58, 59]
            if agentIndex == 0:
                v = -float('inf')
                bestAction = None
                
                for action in actions:
                    successor = state.generateSuccessor(agentIndex, action)
                    score = minimax(nextAgent, nextDepth, successor)
                    
                    if score > v:
                        v = score
                        bestAction = action
                
                # O nível inicial (depth 0) deve retornar a ação, chamadas recursivas retornam o valor [cite: 68, 69]
                return bestAction if depth == 0 else v

            # 5.5. Lógica de Minimização (Turno dos Fantasmas: agentIndex > 0) [cite: 70, 71]
            else:
                v = float('inf')
                
                for action in actions:
                    successor = state.generateSuccessor(agentIndex, action)
                    score = minimax(nextAgent, nextDepth, successor)
                    v = min(v, score)
                
                return v

        # Inicia a recursão e retorna a melhor ação encontrada [cite: 34, 68]
        return minimax(0, 0, gameState)


def betterEvaluationFunction(currentGameState: GameState):
    pos = currentGameState.getPacmanPosition()
    food = currentGameState.getFood().asList()
    ghostStates = currentGameState.getGhostStates()

    # Calcula a distância de Manhattan para a comida mais próxima
    foodDistances = [manhattanDistance(pos, f) for f in food]
    if len(foodDistances) > 0:
        minFoodDistance = min(foodDistances)
    else:
        minFoodDistance = 0

    # Distância para o fantasma mais próximo
    ghostDistances = [manhattanDistance(pos, ghost.getPosition()) for ghost in ghostStates]
    minGhostDistance = min(ghostDistances)

    # Aumenta a pontuação se o fantasma estiver assustado, mas penaliza se estiver muito perto
    scaredTimes = [ghostState.scaredTimer for ghostState in ghostStates]
    if min(scaredTimes) > 0:
        minGhostDistance = 0  # Ignora fantasmas assustados

    return currentGameState.getScore() - (1.5 / (minFoodDistance + 1)) + (2 / (minGhostDistance + 1))

# Abbreviation
better = betterEvaluationFunction
